# COBOL 코드를 Python으로 변환합니다.
def main():
    # 여러 함수 호출
    dan2()
    dan3()
    dan4()
    dan5()
    dan6()
    dan7()
    dan8()
    dan9()
    
# 프로그램 시작
if __name__ == "__main__":
    main()