다음은 COBOL 코드를 Python으로 변환한 코드입니다.

```python
j = 1

while j <= 9:
    result = 4 * j
    print(f"4 * {j} = {result}")
    j += 1
``` 

이 코드는 COBOL 프로그램의 기능을 그대로 유지하면서 가독성을 높였습니다.