# COBOL 프로그램 DAN9을 Python으로 변환합니다.

I = 1
while I <= 9:
    RESULT = 9 * I
    print(f"9 * {I} = {RESULT}")
    I += 1