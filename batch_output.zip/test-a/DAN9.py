# COBOL 코드를 Python으로 변환합니다.
I = 1
while I <= 9:
    RESULT = 9 * I
    print(f"9 * {I} = {RESULT}")
    I += 1