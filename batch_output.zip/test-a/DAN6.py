# COBOL 프로그램을 Python 코드로 변환합니다.

I = 1
while I <= 9:
    RESULT = 6 * I
    print(f"6 * {I} = {RESULT}")
    I += 1