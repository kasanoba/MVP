# COBOL 코드를 Python으로 변환합니다.
# I와 RESULT 변수를 정의하고, 반복문을 사용하여 계산 및 출력합니다.

I = 1
while I <= 9:
    RESULT = 2 * I
    print(f"2 * {I} = {RESULT}")
    I += 1