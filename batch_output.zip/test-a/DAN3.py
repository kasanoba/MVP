아래는 COBOL 코드를 파이썬으로 변환한 코드입니다.

```python
i = 1

while i <= 9:
    result = 3 * i
    print(f"3 * {i} = {result}")
    i += 1
```

이 코드는 COBOL의 기능을 그대로 유지하면서 가독성을 높였습니다.