# COBOL 코드를 Python으로 변환합니다.
I = 1
while I <= 9:
    RESULT = 3 * I
    print(f"3 * {I} = {RESULT}")
    I += 1