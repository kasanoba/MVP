# COBOL 코드 변환 결과입니다.
I = 1
RESULT = 0

while I <= 9:
    RESULT = 7 * I
    print(f"7 * {I} = {RESULT}")
    I += 1