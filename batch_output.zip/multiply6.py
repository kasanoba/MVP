다음은 COBOL 코드를 Python으로 변환한 예입니다:

```python
for j in range(1, 10):
    result = 6 * j
    print(f"6 * {j} = {result}")
``` 

이 코드는 1부터 9까지의 숫자에 6을 곱한 결과를 출력합니다.