다음은 주어진 COBOL 코드를 Python 코드로 변환한 것입니다.

```python
def main():
    print('HELLO, WORLD!')

if __name__ == '__main__':
    main()
``` 

이 코드는 `HELLO, WORLD!`를 출력하고 프로그램을 종료합니다.