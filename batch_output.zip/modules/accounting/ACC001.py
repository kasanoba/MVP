# COBOL 코드를 Python으로 변환합니다.
# DISPLAY는 print로 변환하고, CALL은 함수 호출로 변환합니다.

def util001():
    pass  # 'UTIL001' 함수의 내용은 정의되어 있지 않음

def acc001():
    print("ACCOUNTING MODULE START")
    util001()
    print("ACCOUNTING MODULE END")

# 프로그램 실행
acc001()