# COBOL 코드를 Python으로 변환합니다.
# COBOL의 DISPLAY 문은 Python의 print 함수로 변환됩니다.
# STOP RUN은 Python에서는 프로그램 종료로 간주됩니다.

print("COMMON UTIL CALLED")