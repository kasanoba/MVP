# COBOL 코드를 Python으로 변환합니다.
# COBOL의 DISPLAY 문은 print 문으로 변환하고,
# CALL 문은 해당 함수 호출로 변환합니다.

def util001():
    pass  # 'UTIL001'의 기능을 구현할 위치

print("PAYROLL MODULE START")
util001()
print("PAYROLL MODULE END")